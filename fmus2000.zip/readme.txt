1. Purpose of the program:

FractMus 2000 is a Win32 application that creates Fractal/Algorithmic music using mathematical 
algorithms from chaotic dynamics, fractals, number-theory and cellular automata.  Its features include: 
full midi-file support, sixteen independent voices, complete control of midi parameters 
(instrumentation, voice dynamics, channels, etc), 12 note-generating algorithms, 15 predefined 
musical scales (with the possibility of creating user-defined ones), 11 predefined note 
durations (plus user-defined ones), melody manipulation support (inversion, etc), composition assistants (Composition Maker, Composition Randomizer, Transposer,) full online-documentation/help and more.


2. Installation.

Just unzip fmus2000.zip into a new directory and run setup.exe


3. Status of the program and distribution.

FractMus 2000 is FREEWARE, (c) 1997-1999 by Gustavo Diaz-Jerez.
FractMus can be freely distributed in its unmodified form and 
included it in any software collection such as CD-ROM's but may NOT be sold.  



4. How to contact the Author.

Please send e-mail to:

 gusdiaz@ibm.net or gusdiaz@attglobal.net after October 1, 2000 

or write to:

Gustavo Diaz-Jerez
Calle Abtao No. 29 4A
28007 MADRID, Spain

Visit FractMus' Webpage at www.geocities.com/SiliconValley/Haven/4386

